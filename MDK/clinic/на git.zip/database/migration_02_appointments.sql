-- ============================================================
-- migration_02_appointments.sql: обновление УЖЕ СОЗДАННОЙ базы
-- Добавляет к записям: время начала, длительность, повод, комментарий,
-- и новое право appointment.manage для администратора.
-- Запускать ОДИН РАЗ (повторный запуск выдаст ошибку "Duplicate column").
-- Если вы создаёте базу заново через schema.sql, этот файл НЕ нужен.
-- ============================================================

SET NAMES utf8mb4;
USE ophthalmology_clinic;

ALTER TABLE appointments
    ADD COLUMN start_time TIME NULL AFTER slot_id,
    ADD COLUMN duration_minutes SMALLINT UNSIGNED NULL AFTER start_time,
    ADD COLUMN reason ENUM('consultation','diagnostics','manipulation','glasses','surgery')
        NOT NULL DEFAULT 'consultation' AFTER duration_minutes,
    ADD COLUMN note VARCHAR(500) NULL AFTER reason;

INSERT IGNORE INTO permissions (id, code, description)
VALUES (13, 'appointment.manage', 'Запись пациентов в расписание, перенос и удаление записей');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, 13 FROM roles r WHERE r.name = 'administrator';
