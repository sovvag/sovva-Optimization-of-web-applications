-- ============================================================
-- schema.sql: структура базы данных ophthalmology_clinic
-- Запуск: phpMyAdmin -> вкладка SQL -> вставить весь файл -> Вперёд
-- Файл можно запускать повторно: старые таблицы будут удалены!
-- ============================================================

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS ophthalmology_clinic
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE ophthalmology_clinic;

-- Удаляем старые таблицы (если они уже были)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS slots;
DROP TABLE IF EXISTS work_schedules;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS specialties;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS role_permissions;
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS roles;
SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- 1. Роли: patient, administrator, manager, sysadmin
-- ------------------------------------------------------------
CREATE TABLE roles (
    id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name  VARCHAR(50)  NOT NULL,          -- код роли (латиницей)
    title VARCHAR(100) NOT NULL,          -- название для экрана
    PRIMARY KEY (id),
    UNIQUE KEY uq_roles_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 2. Права (что можно делать на сайте)
-- ------------------------------------------------------------
CREATE TABLE permissions (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code        VARCHAR(50)  NOT NULL,    -- например: patients.manage
    description VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_permissions_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 3. Какие права у какой роли (это редактирует сисадмин)
-- ------------------------------------------------------------
CREATE TABLE role_permissions (
    role_id       INT UNSIGNED NOT NULL,
    permission_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (role_id, permission_id),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_id)
        REFERENCES roles (id) ON DELETE CASCADE,
    CONSTRAINT fk_rp_permission FOREIGN KEY (permission_id)
        REFERENCES permissions (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 4. Пользователи сайта (вход по email и паролю)
-- ------------------------------------------------------------
CREATE TABLE users (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    email         VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,  -- хэш, сам пароль не хранится
    role_id       INT UNSIGNED NOT NULL,
    last_name     VARCHAR(60)  NOT NULL,
    first_name    VARCHAR(60)  NOT NULL,
    middle_name   VARCHAR(60)  NULL,
    birth_date    DATE         NULL,
    avatar_path   VARCHAR(255) NULL,
    is_active     TINYINT(1)   NOT NULL DEFAULT 1,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    CONSTRAINT fk_users_role FOREIGN KEY (role_id)
        REFERENCES roles (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 5. Картотека пациентов
-- user_id может быть пустым: администратор добавляет пациента без аккаунта
-- ------------------------------------------------------------
CREATE TABLE patients (
    id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id            INT UNSIGNED NULL,
    last_name          VARCHAR(60)  NOT NULL,
    first_name         VARCHAR(60)  NOT NULL,
    middle_name        VARCHAR(60)  NULL,
    birth_date         DATE         NULL,
    phone              VARCHAR(20)  NULL,
    address            VARCHAR(255) NULL,
    pd_consent_refused TINYINT(1)   NOT NULL DEFAULT 0,  -- отказ от обработки ПД
    created_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_patients_user (user_id),
    CONSTRAINT fk_patients_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 6. Специальности врачей
-- ------------------------------------------------------------
CREATE TABLE specialties (
    id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_specialties_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 7. Врачи
-- slug нужен для красивого адреса: /doctors/smirnova-elena
-- ------------------------------------------------------------
CREATE TABLE doctors (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id          INT UNSIGNED NULL,
    specialty_id     INT UNSIGNED NOT NULL,
    last_name        VARCHAR(60)  NOT NULL,
    first_name       VARCHAR(60)  NOT NULL,
    middle_name      VARCHAR(60)  NULL,
    slug             VARCHAR(120) NOT NULL,
    experience_years TINYINT UNSIGNED NOT NULL DEFAULT 0,
    patient_category ENUM('adults','children','children14_adults') NOT NULL DEFAULT 'adults',
    photo_path       VARCHAR(255) NULL,
    skills           TEXT         NULL,   -- навыки через запятую
    price            DECIMAL(10,2) NOT NULL DEFAULT 0,
    is_active        TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uq_doctors_slug (slug),
    CONSTRAINT fk_doctors_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_doctors_specialty FOREIGN KEY (specialty_id)
        REFERENCES specialties (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 8. График работы врачей (одна смена в день)
-- ------------------------------------------------------------
CREATE TABLE work_schedules (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    doctor_id    INT UNSIGNED NOT NULL,
    work_date    DATE         NOT NULL,
    start_time   TIME         NOT NULL,
    end_time     TIME         NOT NULL,
    slot_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 30,  -- длина приёма
    PRIMARY KEY (id),
    UNIQUE KEY uq_schedule_doctor_date (doctor_id, work_date),
    CONSTRAINT fk_ws_doctor FOREIGN KEY (doctor_id)
        REFERENCES doctors (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 9. Слоты (ячейки времени для записи)
-- free = свободно, pending = ждёт одобрения, booked = занято
-- ------------------------------------------------------------
CREATE TABLE slots (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    doctor_id   INT UNSIGNED NOT NULL,
    schedule_id INT UNSIGNED NOT NULL,
    slot_date   DATE         NOT NULL,
    slot_time   TIME         NOT NULL,
    status      ENUM('free','pending','booked') NOT NULL DEFAULT 'free',
    PRIMARY KEY (id),
    UNIQUE KEY uq_slots_unique (doctor_id, slot_date, slot_time),
    KEY idx_slots_date_status (slot_date, status),
    CONSTRAINT fk_slots_doctor FOREIGN KEY (doctor_id)
        REFERENCES doctors (id) ON DELETE CASCADE,
    CONSTRAINT fk_slots_schedule FOREIGN KEY (schedule_id)
        REFERENCES work_schedules (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 10. Записи на приём
-- ------------------------------------------------------------
CREATE TABLE appointments (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id   INT UNSIGNED NOT NULL,
    doctor_id    INT UNSIGNED NOT NULL,
    slot_id      INT UNSIGNED NOT NULL,
    start_time   TIME NULL,                -- фактическое начало приёма (NULL = время слота)
    duration_minutes SMALLINT UNSIGNED NULL, -- длительность (NULL = длительность слота)
    reason       ENUM('consultation','diagnostics','manipulation','glasses','surgery')
                 NOT NULL DEFAULT 'consultation',   -- повод обращения
    note         VARCHAR(500) NULL,        -- комментарий к записи
    status       ENUM('pending','confirmed','rejected','cancelled','completed')
                 NOT NULL DEFAULT 'pending',
    price        DECIMAL(10,2) NOT NULL DEFAULT 0,
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    confirmed_by INT UNSIGNED NULL,       -- какой администратор одобрил
    confirmed_at DATETIME     NULL,
    PRIMARY KEY (id),
    KEY idx_app_status (status),
    KEY idx_app_patient (patient_id),
    CONSTRAINT fk_app_patient FOREIGN KEY (patient_id)
        REFERENCES patients (id),
    CONSTRAINT fk_app_doctor FOREIGN KEY (doctor_id)
        REFERENCES doctors (id),
    CONSTRAINT fk_app_slot FOREIGN KEY (slot_id)
        REFERENCES slots (id),
    CONSTRAINT fk_app_confirmed_by FOREIGN KEY (confirmed_by)
        REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 11. Уведомления администратору о новых заявках
-- ------------------------------------------------------------
CREATE TABLE notifications (
    id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    appointment_id INT UNSIGNED NOT NULL,
    type           VARCHAR(30)  NOT NULL DEFAULT 'new_appointment',
    is_read        TINYINT(1)   NOT NULL DEFAULT 0,
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_notif_read (is_read),
    CONSTRAINT fk_notif_app FOREIGN KEY (appointment_id)
        REFERENCES appointments (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 12. Журнал действий (для отчёта по работе администраторов)
-- ------------------------------------------------------------
CREATE TABLE audit_log (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    INT UNSIGNED NULL,
    action     VARCHAR(50)  NOT NULL,     -- например: appointment.confirm
    entity     VARCHAR(50)  NOT NULL,     -- например: appointment
    entity_id  INT UNSIGNED NULL,
    details    VARCHAR(255) NULL,
    ip         VARCHAR(45)  NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_audit_user (user_id),
    KEY idx_audit_date (created_at),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 13. Попытки входа (защита от подбора пароля)
-- ------------------------------------------------------------
CREATE TABLE login_attempts (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    ip           VARCHAR(45)  NOT NULL,
    email        VARCHAR(150) NULL,
    attempted_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_login_ip (ip, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
