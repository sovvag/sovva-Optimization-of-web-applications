-- ============================================================
-- seed_demo.sql: демо-пациенты и записи, чтобы таблица расписания
-- администратора не была пустой. Запускать ПОСЛЕ seed_schedule.sql
-- и seed_users.sql. Запускать ОДИН РАЗ.
--
-- Записи ставятся на ближайший день, когда работают минимум 3 врача.
-- Ожидающие заявки (жёлтые) создают уведомления: они появятся
-- в правом нижнем углу при входе под администратором.
-- ============================================================

SET NAMES utf8mb4;
USE ophthalmology_clinic;

-- Демо-пациенты без аккаунта на сайте
INSERT INTO patients (last_name, first_name, middle_name, birth_date, phone) VALUES
('Петров',   'Иван',    'Иванович',   '1980-02-14', '+7 900 111-11-01'),
('Сидорова', 'Ксения',  'Андреевна',  '1992-07-03', '+7 900 111-11-02'),
('Макаров',  'Евгений', 'Викторович', '1975-11-21', '+7 900 111-11-03'),
('Ким',      'Лариса',  'Романовна',  '1988-05-30', '+7 900 111-11-04'),
('Лебедева', 'Ольга',   'Павловна',   '2001-09-12', '+7 900 111-11-05'),
('Зайцев',   'Роман',   'Тимурович',  '1969-01-08', '+7 900 111-11-06');

SET @adm = (SELECT id FROM users WHERE email = 'admin@clinic.local');
SET @demo_date = (SELECT slot_date FROM slots WHERE slot_date >= CURDATE()
                  GROUP BY slot_date HAVING COUNT(DISTINCT doctor_id) >= 3
                  ORDER BY slot_date LIMIT 1);
SET @d1 = (SELECT id FROM doctors WHERE slug = 'ivanov-aleksey');
SET @d2 = (SELECT id FROM doctors WHERE slug = 'kozlov-dmitriy');
SET @d3 = (SELECT id FROM doctors WHERE slug = 'smirnova-elena');
SET @d4 = (SELECT id FROM doctors WHERE slug = 'orlova-mariya');
SET @p1 = (SELECT id FROM patients WHERE phone = '+7 900 111-11-01');
SET @p2 = (SELECT id FROM patients WHERE phone = '+7 900 111-11-02');
SET @p3 = (SELECT id FROM patients WHERE phone = '+7 900 111-11-03');
SET @p4 = (SELECT id FROM patients WHERE phone = '+7 900 111-11-04');
SET @p5 = (SELECT id FROM patients WHERE phone = '+7 900 111-11-05');
SET @p6 = (SELECT id FROM patients WHERE phone = '+7 900 111-11-06');
SET @ptest = (SELECT id FROM patients WHERE user_id = (SELECT id FROM users WHERE email = 'patient@clinic.local'));

-- Иванов: подтверждённые и одна заявка
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p1, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d1 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 0;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p2, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d1 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 1;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p3, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d1 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 3;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price)
SELECT @p6, s.doctor_id, s.id, 'pending', d.price FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d1 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 4;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p5, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d1 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 6;

-- Козлов (приём 60 минут)
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p4, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d2 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 0;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price)
SELECT @p2, s.doctor_id, s.id, 'pending', d.price FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d2 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 2;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p6, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d2 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 4;

-- Смирнова (одна заявка от тестового пациента patient@clinic.local)
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p5, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d3 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 1;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price)
SELECT @ptest, s.doctor_id, s.id, 'pending', d.price FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d3 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 2;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p3, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d3 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 5;

-- Орлова
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price)
SELECT @p4, s.doctor_id, s.id, 'pending', d.price FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d4 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 1;
INSERT INTO appointments (patient_id, doctor_id, slot_id, status, price, confirmed_by, confirmed_at)
SELECT @p1, s.doctor_id, s.id, 'confirmed', d.price, @adm, NOW() FROM slots s JOIN doctors d ON d.id = s.doctor_id
WHERE s.doctor_id = @d4 AND s.slot_date = @demo_date AND s.status = 'free' ORDER BY s.slot_time LIMIT 1 OFFSET 3;

-- Статусы слотов по созданным записям
UPDATE slots SET status = 'booked'  WHERE id IN (SELECT slot_id FROM appointments WHERE status = 'confirmed');
UPDATE slots SET status = 'pending' WHERE id IN (SELECT slot_id FROM appointments WHERE status = 'pending');

-- Уведомления администратору по ожидающим заявкам
INSERT INTO notifications (appointment_id, type)
SELECT id, 'new_appointment' FROM appointments WHERE status = 'pending';

-- Эту дату откройте в расписании:
SELECT @demo_date AS demo_date;
