-- ============================================================
-- seed.sql: начальные данные (запускать ПОСЛЕ schema.sql)
-- ============================================================

SET NAMES utf8mb4;
USE ophthalmology_clinic;

-- Роли
INSERT INTO roles (id, name, title) VALUES
(1, 'patient',       'Пациент'),
(2, 'administrator', 'Администратор'),
(3, 'manager',       'Руководитель'),
(4, 'sysadmin',      'Системный администратор');

-- Права
INSERT INTO permissions (id, code, description) VALUES
(1,  'doctors.view',         'Просмотр списка и карточек врачей'),
(2,  'appointment.create',   'Запись на приём'),
(3,  'appointment.view_own', 'Просмотр своих записей'),
(4,  'appointment.approve',  'Одобрение и отклонение заявок'),
(5,  'schedule.view',        'Просмотр расписания'),
(6,  'patients.manage',      'Картотека пациентов: добавить, изменить, удалить'),
(7,  'work_schedule.manage', 'Управление графиком работы врачей'),
(8,  'doctors.manage',       'Добавление и редактирование врачей'),
(9,  'reports.view',         'Просмотр отчётов'),
(10, 'roles.manage',         'Управление правами ролей'),
(11, 'users.manage',         'Управление пользователями'),
(12, 'profile.edit',         'Редактирование своего профиля'),
(13, 'appointment.manage',   'Запись пациентов в расписание, перенос и удаление записей');

-- Пациент
INSERT INTO role_permissions (role_id, permission_id) VALUES
(1, 1), (1, 2), (1, 3), (1, 12);

-- Администратор
INSERT INTO role_permissions (role_id, permission_id) VALUES
(2, 4), (2, 5), (2, 6), (2, 12), (2, 13);

-- Руководитель
INSERT INTO role_permissions (role_id, permission_id) VALUES
(3, 5), (3, 6), (3, 7), (3, 8), (3, 9), (3, 12);

-- Системный администратор
INSERT INTO role_permissions (role_id, permission_id) VALUES
(4, 10), (4, 11), (4, 12);

-- Специальности
INSERT INTO specialties (id, name) VALUES
(1, 'Офтальмолог'),
(2, 'Офтальмохирург'),
(3, 'Ретинолог');

-- Тестовые врачи (потом добавим через форму руководителя)
INSERT INTO doctors
(specialty_id, last_name, first_name, middle_name, slug, experience_years, patient_category, skills, price) VALUES
(1, 'Иванов',   'Алексей', 'Петрович',   'ivanov-aleksey',   15, 'adults',
    'Проверка зрения, Подбор очков, Измерение внутриглазного давления', 2500.00),
(2, 'Козлов',   'Дмитрий', 'Сергеевич',  'kozlov-dmitriy',   18, 'adults',
    'Операции при катаракте, Лечение глаукомы, Лазерная коррекция', 6000.00),
(3, 'Смирнова', 'Елена',   'Викторовна', 'smirnova-elena',   12, 'children14_adults',
    'ОКТ сетчатки, Лазерная коагуляция, Диабетическая ретинопатия', 3500.00),
(1, 'Орлова',   'Мария',   'Николаевна', 'orlova-mariya',     8, 'children',
    'Детская офтальмология, Лечение косоглазия, Подбор очков', 2800.00);

-- Пользователи не добавляем: пароль должен быть захэширован через PHP.
-- Тестовых пользователей создадим на следующем шаге скриптом на PHP.
