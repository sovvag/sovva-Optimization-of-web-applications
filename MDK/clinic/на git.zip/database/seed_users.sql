-- ============================================================
-- seed_users.sql: тестовые пользователи (запускать ПОСЛЕ seed.sql)
-- Пароль у всех четырёх: Test1234
-- Хэши созданы алгоритмом bcrypt (как password_hash в PHP).
-- ВАЖНО: на настоящем сайте эти аккаунты нужно удалить!
-- ============================================================

SET NAMES utf8mb4;
USE ophthalmology_clinic;

INSERT INTO users (email, password_hash, role_id, last_name, first_name, middle_name, birth_date) VALUES
('patient@clinic.local',   '$2y$10$FZ11DuVQXE8Nv2fY/D4wluwiL/G5HxLiJ58O5rvNGCqjQFh9mKuZi',
    (SELECT id FROM roles WHERE name = 'patient'),       'Орлова',  'Татьяна', 'Сергеевна',   '1994-05-12'),
('admin@clinic.local',     '$2y$10$C5et9LQjI3pRRu7lKrHQJuT2mPKus2bkoV/mlvD7oHD/joq5h99dO',
    (SELECT id FROM roles WHERE name = 'administrator'), 'Козлова', 'Анна',    'Николаевна',  '1991-03-21'),
('manager@clinic.local',   '$2y$10$wqjOe8KY7r1Q3mIvG62bhOWf2fneNUhW8CJF0Ug34gDtwVTYn.3Ni',
    (SELECT id FROM roles WHERE name = 'manager'),       'Белов',   'Сергей',  'Игоревич',    '1985-11-02'),
('sysadmin@clinic.local',  '$2y$10$Wj.5fj2JKJSGQJP8cGuUWOhL44HCpY6PKzCFnBSfOZJc2z.oukO9S',
    (SELECT id FROM roles WHERE name = 'sysadmin'),      'Тихонов', 'Павел',   'Андреевич',   '1989-07-30');

-- Карточка пациента для тестового пациента
INSERT INTO patients (user_id, last_name, first_name, middle_name, birth_date)
SELECT id, last_name, first_name, middle_name, birth_date FROM users WHERE email = 'patient@clinic.local';
