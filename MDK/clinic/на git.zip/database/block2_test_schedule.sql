-- Пример смены для врача id=1 на 20.11.2026. Проверьте, что смены ещё нет.
INSERT INTO work_schedules(doctor_id,work_date,start_time,end_time,slot_minutes) VALUES(1,'2026-11-20','09:00:00','12:00:00',30);
SET @sid=LAST_INSERT_ID();
INSERT INTO slots(doctor_id,schedule_id,slot_date,slot_time,status) VALUES
(1,@sid,'2026-11-20','09:00:00','free'),(1,@sid,'2026-11-20','09:30:00','free'),
(1,@sid,'2026-11-20','10:00:00','free'),(1,@sid,'2026-11-20','10:30:00','free'),
(1,@sid,'2026-11-20','11:00:00','free'),(1,@sid,'2026-11-20','11:30:00','free');
