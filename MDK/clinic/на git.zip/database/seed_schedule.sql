-- ============================================================
-- seed_schedule.sql: смены врачей и свободное время на 30 дней вперёд
-- Запускать ПОСЛЕ seed.sql. Файл можно запускать повторно:
-- уже существующие смены и слоты не дублируются.
--
-- Графики работы (ДЛЯ ТЕСТА):
--   Иванов    пн-пт       09:00-15:00, приём 30 минут
--   Козлов    пн, ср, пт  10:00-16:00, приём 60 минут (хирург)
--   Смирнова  пн-чт       09:00-14:00, приём 30 минут
--   Орлова    вт, чт, сб  11:00-17:00, приём 30 минут
-- ============================================================

SET NAMES utf8mb4;
USE ophthalmology_clinic;

-- Вспомогательная таблица с числами 0..39 (дни и номера слотов)
DROP TEMPORARY TABLE IF EXISTS nums;
CREATE TEMPORARY TABLE nums (n INT NOT NULL PRIMARY KEY);
INSERT INTO nums (n)
SELECT a.n + b.n * 10
FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
      UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a
CROSS JOIN (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) b;

-- Смены (WEEKDAY: 0 = понедельник ... 6 = воскресенье)
INSERT IGNORE INTO work_schedules (doctor_id, work_date, start_time, end_time, slot_minutes)
SELECT d.id, CURDATE() + INTERVAL n.n DAY, '09:00:00', '15:00:00', 30
FROM doctors d CROSS JOIN nums n
WHERE d.slug = 'ivanov-aleksey' AND n.n < 30
  AND WEEKDAY(CURDATE() + INTERVAL n.n DAY) IN (0, 1, 2, 3, 4);

INSERT IGNORE INTO work_schedules (doctor_id, work_date, start_time, end_time, slot_minutes)
SELECT d.id, CURDATE() + INTERVAL n.n DAY, '10:00:00', '16:00:00', 60
FROM doctors d CROSS JOIN nums n
WHERE d.slug = 'kozlov-dmitriy' AND n.n < 30
  AND WEEKDAY(CURDATE() + INTERVAL n.n DAY) IN (0, 2, 4);

INSERT IGNORE INTO work_schedules (doctor_id, work_date, start_time, end_time, slot_minutes)
SELECT d.id, CURDATE() + INTERVAL n.n DAY, '09:00:00', '14:00:00', 30
FROM doctors d CROSS JOIN nums n
WHERE d.slug = 'smirnova-elena' AND n.n < 30
  AND WEEKDAY(CURDATE() + INTERVAL n.n DAY) IN (0, 1, 2, 3);

INSERT IGNORE INTO work_schedules (doctor_id, work_date, start_time, end_time, slot_minutes)
SELECT d.id, CURDATE() + INTERVAL n.n DAY, '11:00:00', '17:00:00', 30
FROM doctors d CROSS JOIN nums n
WHERE d.slug = 'orlova-mariya' AND n.n < 30
  AND WEEKDAY(CURDATE() + INTERVAL n.n DAY) IN (1, 3, 5);

-- Слоты: от начала смены с шагом slot_minutes, пока не наступит конец смены
INSERT IGNORE INTO slots (doctor_id, schedule_id, slot_date, slot_time, status)
SELECT ws.doctor_id, ws.id, ws.work_date,
       ADDTIME(ws.start_time, SEC_TO_TIME(n.n * ws.slot_minutes * 60)), 'free'
FROM work_schedules ws CROSS JOIN nums n
WHERE ws.work_date >= CURDATE()
  AND ADDTIME(ws.start_time, SEC_TO_TIME(n.n * ws.slot_minutes * 60)) < ws.end_time;

DROP TEMPORARY TABLE nums;

SELECT COUNT(*) AS slots_created FROM slots;
